// import React, { useState, useEffect } from 'react';
// import { useParams, useNavigate, Link } from 'react-router-dom';
// import axios from 'axios';
// import { useAuth } from '../../contexts/AuthContext';
// import { 
//   PlayCircle, 
//   Calendar, 
//   Clock, 
//   User, 
//   Video, 
//   ArrowLeft,
//   Loader2,
//   AlertCircle,
//   ExternalLink,
//   FileVideo,
//   Users,
//   Hash
// } from 'lucide-react';

// const CourseRecordingsPage = () => {
//   const { courseId } = useParams();
//   const navigate = useNavigate();
//   const { token } = useAuth();
  
//   const [course, setCourse] = useState(null);
//   const [recordings, setRecordings] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [loadingRecordings, setLoadingRecordings] = useState(false);
//   const [error, setError] = useState(null);
//   const [selectedSession, setSelectedSession] = useState(null);
//   const [sessionRecordings, setSessionRecordings] = useState([]);

//   // Fetch course details
//   useEffect(() => {
//     const fetchCourseDetails = async () => {
//       try {
//         setLoading(true);
//         setError(null);
        
//         // Fetch course details from your API
//         const response = await axios.get(
//           `${process.env.REACT_APP_API_URL}/course/getAllCourses`,
//           {
//             headers: {
//               'Authorization': `Bearer ${token}`,
//               'Content-Type': 'application/json'
//             },
//             params: {
//               page: 1,
//               limit: 10
//             }
//           }
//         );

//         if (response.data.success) {
//           // Find the specific course by ID
//           const foundCourse = response.data.data.courses.find(
//             course => course._id === courseId
//           );
          
//           if (foundCourse) {
//             setCourse(foundCourse);
//             // Set first session as selected by default if exists
//             if (foundCourse.liveClasses && foundCourse.liveClasses.length > 0) {
//               setSelectedSession(foundCourse.liveClasses[0]);
//               // Fetch recordings for the first session
//               fetchSessionRecordings(foundCourse.liveClasses[0].sessionId);
//             }
//           } else {
//             setError('Course not found');
//           }
//         } else {
//           setError('Failed to fetch course details');
//         }
//       } catch (err) {
//         console.error('Error fetching course:', err);
//         setError(err.response?.data?.message || 'Failed to load course details');
//       } finally {
//         setLoading(false);
//       }
//     };

//     if (courseId && token) {
//       fetchCourseDetails();
//     }
//   }, [courseId, token]);

//   // Fetch recordings for a specific session
//   const fetchSessionRecordings = async (sessionId) => {
//     if (!sessionId) return;
    
//     try {
//       setLoadingRecordings(true);
//       setSessionRecordings([]);
      
//       const response = await axios.get(
//         `${process.env.REACT_APP_API_URL}/liveSession/${sessionId}/recordings`,
//         {
//           headers: {
//             'Authorization': `Bearer ${token}`,
//             'Content-Type': 'application/json'
//           }
//         }
//       );

//       if (response.data.success) {
//         setSessionRecordings(response.data.data.recordings || []);
//       } else {
//         setSessionRecordings([]);
//       }
//     } catch (err) {
//       console.error('Error fetching recordings:', err);
//       setSessionRecordings([]);
//     } finally {
//       setLoadingRecordings(false);
//     }
//   };

//   // Handle session selection
//   const handleSessionSelect = (session) => {
//     setSelectedSession(session);
//     fetchSessionRecordings(session.sessionId);
//   };

//   // Format date
//   const formatDate = (dateString) => {
//     const date = new Date(dateString);
//     return date.toLocaleDateString('en-US', {
//       weekday: 'long',
//       year: 'numeric',
//       month: 'long',
//       day: 'numeric'
//     });
//   };

//   // Format time
//   const formatTime = (dateString) => {
//     const date = new Date(dateString);
//     return date.toLocaleTimeString('en-US', {
//       hour: '2-digit',
//       minute: '2-digit'
//     });
//   };

//   // Calculate session duration
//   const getSessionDuration = (minutes) => {
//     if (minutes < 60) {
//       return `${minutes} min`;
//     }
//     const hours = Math.floor(minutes / 60);
//     const mins = minutes % 60;
//     return mins > 0 ? `${hours}h ${mins}m` : `${hours}h`;
//   };

//   // Get session status badge color
//   const getStatusColor = (status) => {
//     switch (status) {
//       case 'SCHEDULED':
//         return 'bg-blue-100 text-blue-800';
//       case 'LIVE':
//         return 'bg-green-100 text-green-800';
//       case 'COMPLETED':
//         return 'bg-purple-100 text-purple-800';
//       case 'CANCELLED':
//         return 'bg-red-100 text-red-800';
//       default:
//         return 'bg-gray-100 text-gray-800';
//     }
//   };

//   if (loading) {
//     return (
//       <div className="min-h-screen bg-gray-50 flex items-center justify-center">
//         <div className="text-center">
//           <Loader2 className="h-12 w-12 animate-spin text-blue-600 mx-auto mb-4" />
//           <p className="text-gray-600">Loading course details...</p>
//         </div>
//       </div>
//     );
//   }

//   if (error) {
//     return (
//       <div className="min-h-screen bg-gray-50 flex items-center justify-center">
//         <div className="max-w-md w-full bg-white rounded-lg shadow-lg p-8 text-center">
//           <AlertCircle className="h-16 w-16 text-red-500 mx-auto mb-4" />
//           <h2 className="text-2xl font-bold text-gray-800 mb-2">Error</h2>
//           <p className="text-gray-600 mb-6">{error}</p>
//           <button
//             onClick={() => navigate('/courses')}
//             className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
//           >
//             Back to Courses
//           </button>
//         </div>
//       </div>
//     );
//   }

//   if (!course) {
//     return (
//       <div className="min-h-screen bg-gray-50 flex items-center justify-center">
//         <div className="max-w-md w-full bg-white rounded-lg shadow-lg p-8 text-center">
//           <AlertCircle className="h-16 w-16 text-yellow-500 mx-auto mb-4" />
//           <h2 className="text-2xl font-bold text-gray-800 mb-2">Course Not Found</h2>
//           <p className="text-gray-600 mb-6">The requested course could not be found.</p>
//           <button
//             onClick={() => navigate('/courses')}
//             className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
//           >
//             Back to Courses
//           </button>
//         </div>
//       </div>
//     );
//   }

//   return (
//     <div className="min-h-screen bg-gray-50">
//       {/* Header */}
//       <div className="bg-white shadow">
//         <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
//           <div className="flex items-center justify-between py-4">
//             <div className="flex items-center space-x-4">
//               <button
//                 onClick={() => navigate(-1)}
//                 className="flex items-center text-gray-600 hover:text-gray-900"
//               >
//                 <ArrowLeft className="h-5 w-5 mr-2" />
//                 Back
//               </button>
//               <div className="h-8 w-px bg-gray-300" />
//               <h1 className="text-2xl font-bold text-gray-900">Course Recordings</h1>
//             </div>
//             <Link
//               to={`/courses/${courseId}`}
//               className="flex items-center text-blue-600 hover:text-blue-800"
//             >
//               <ExternalLink className="h-5 w-5 mr-2" />
//               Go to Course
//             </Link>
//           </div>
//         </div>
//       </div>

//       <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
//         {/* Course Info Card */}
//         <div className="bg-white rounded-lg shadow-lg overflow-hidden mb-8">
//           <div className="p-6">
//             <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
//               <div>
//                 <h2 className="text-2xl font-bold text-gray-900 mb-2">{course.title}</h2>
//                 <p className="text-gray-600">{course.description}</p>
//               </div>
//               <div className="mt-4 md:mt-0">
//                 <div className="flex items-center space-x-4">
//                   <div className="flex items-center text-gray-600">
//                     <User className="h-5 w-5 mr-2" />
//                     <span>{course.instructor}</span>
//                   </div>
//                   <div className="flex items-center text-gray-600">
//                     <Video className="h-5 w-5 mr-2" />
//                     <span>{course.liveClasses?.length || 0} Sessions</span>
//                   </div>
//                 </div>
//               </div>
//             </div>
//           </div>
//         </div>

//         <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
//           {/* Left Column - Sessions List */}
//           <div className="lg:col-span-1">
//             <div className="bg-white rounded-lg shadow-lg overflow-hidden">
//               <div className="px-6 py-4 border-b border-gray-200">
//                 <h3 className="text-lg font-semibold text-gray-900 flex items-center">
//                   <Calendar className="h-5 w-5 mr-2" />
//                   Live Sessions
//                 </h3>
//                 <p className="text-sm text-gray-500 mt-1">
//                   Select a session to view recordings
//                 </p>
//               </div>
              
//               <div className="overflow-y-auto max-h-[600px]">
//                 {course.liveClasses && course.liveClasses.length > 0 ? (
//                   <div className="divide-y divide-gray-200">
//                     {course.liveClasses.map((session) => (
//                       <button
//                         key={session._id}
//                         onClick={() => handleSessionSelect(session)}
//                         className={`w-full text-left p-4 hover:bg-gray-50 transition-colors ${
//                           selectedSession?._id === session._id ? 'bg-blue-50 border-l-4 border-blue-600' : ''
//                         }`}
//                       >
//                         <div className="flex justify-between items-start mb-2">
//                           <h4 className="font-medium text-gray-900">{session.sessionTitle}</h4>
//                           <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(session.status)}`}>
//                             {session.status}
//                           </span>
//                         </div>
                        
//                         <div className="space-y-2 text-sm text-gray-600">
//                           <div className="flex items-center">
//                             <Clock className="h-4 w-4 mr-2" />
//                             <span>
//                               {formatDate(session.scheduleAt)} • {formatTime(session.scheduleAt)}
//                             </span>
//                           </div>
                          
//                           <div className="flex items-center">
//                             <Hash className="h-4 w-4 mr-2" />
//                             <span>Room: {session.roomCode}</span>
//                           </div>
                          
//                           <div className="flex items-center">
//                             <Users className="h-4 w-4 mr-2" />
//                             <span>Duration: {getSessionDuration(session.duration)}</span>
//                           </div>
//                         </div>
                        
//                         {session.description && (
//                           <p className="mt-3 text-sm text-gray-500 line-clamp-2">
//                             {session.description}
//                           </p>
//                         )}
//                       </button>
//                     ))}
//                   </div>
//                 ) : (
//                   <div className="p-8 text-center">
//                     <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
//                     <h4 className="font-medium text-gray-900 mb-2">No Live Sessions</h4>
//                     <p className="text-gray-500">This course doesn't have any live sessions yet.</p>
//                   </div>
//                 )}
//               </div>
//             </div>
//           </div>

//           {/* Right Column - Recordings */}
//           <div className="lg:col-span-2">
//             <div className="bg-white rounded-lg shadow-lg overflow-hidden h-full">
//               {selectedSession ? (
//                 <>
//                   <div className="px-6 py-4 border-b border-gray-200">
//                     <div className="flex justify-between items-center">
//                       <div>
//                         <h3 className="text-lg font-semibold text-gray-900 flex items-center">
//                           <FileVideo className="h-5 w-5 mr-2" />
//                           Recordings for: {selectedSession.sessionTitle}
//                         </h3>
//                         <p className="text-sm text-gray-500 mt-1">
//                           Scheduled: {formatDate(selectedSession.scheduleAt)} at {formatTime(selectedSession.scheduleAt)}
//                         </p>
//                       </div>
//                       <div className="flex items-center space-x-2">
//                         <Hash className="h-5 w-5 text-gray-400" />
//                         <span className="font-mono bg-gray-100 px-3 py-1 rounded text-sm">
//                           {selectedSession.roomCode}
//                         </span>
//                       </div>
//                     </div>
//                   </div>

//                   <div className="p-6">
//                     {loadingRecordings ? (
//                       <div className="text-center py-12">
//                         <Loader2 className="h-12 w-12 animate-spin text-blue-600 mx-auto mb-4" />
//                         <p className="text-gray-600">Loading recordings...</p>
//                       </div>
//                     ) : sessionRecordings.length > 0 ? (
//                       <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
//                         {sessionRecordings.map((recording, index) => (
//                           <div
//                             key={index}
//                             className="border border-gray-200 rounded-lg overflow-hidden hover:shadow-md transition-shadow"
//                           >
//                             <div className="aspect-video bg-gray-900 relative">
//                               {/* Video thumbnail preview */}
//                               <div className="absolute inset-0 flex items-center justify-center">
//                                 <PlayCircle className="h-16 w-16 text-white opacity-75" />
//                               </div>
//                               <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4">
//                                 <p className="text-white font-medium">
//                                   Recording {index + 1}
//                                 </p>
//                               </div>
//                             </div>
                            
//                             <div className="p-4">
//                               <h4 className="font-medium text-gray-900 mb-2">
//                                 {recording.title || `Session Recording - Part ${index + 1}`}
//                               </h4>
                              
//                               {recording.duration && (
//                                 <p className="text-sm text-gray-600 mb-3 flex items-center">
//                                   <Clock className="h-4 w-4 mr-2" />
//                                   {getSessionDuration(recording.duration)}
//                                 </p>
//                               )}
                              
//                               <a
//                                 href={recording.url}
//                                 target="_blank"
//                                 rel="noopener noreferrer"
//                                 className="inline-flex items-center justify-center w-full bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
//                               >
//                                 <PlayCircle className="h-5 w-5 mr-2" />
//                                 Watch Recording
//                               </a>
//                             </div>
//                           </div>
//                         ))}
//                       </div>
//                     ) : (
//                       <div className="text-center py-12">
//                         <FileVideo className="h-16 w-16 text-gray-400 mx-auto mb-4" />
//                         <h4 className="font-medium text-gray-900 mb-2">No Recordings Available</h4>
//                         <p className="text-gray-500 mb-6">
//                           {selectedSession.status === 'SCHEDULED'
//                             ? 'Recordings will be available after the session is completed.'
//                             : 'No recordings were captured for this session.'}
//                         </p>
//                         <div className="flex items-center justify-center space-x-4 text-sm text-gray-600">
//                           <div className="flex items-center">
//                             <Users className="h-4 w-4 mr-2" />
//                             <span>Status: {selectedSession.status}</span>
//                           </div>
//                           <div className="flex items-center">
//                             <Clock className="h-4 w-4 mr-2" />
//                             <span>Duration: {getSessionDuration(selectedSession.duration)}</span>
//                           </div>
//                         </div>
//                       </div>
//                     )}

//                     {/* Session Details */}
//                     {selectedSession.description && (
//                       <div className="mt-8 pt-8 border-t border-gray-200">
//                         <h4 className="font-medium text-gray-900 mb-3">Session Description</h4>
//                         <p className="text-gray-600 whitespace-pre-line">
//                           {selectedSession.description}
//                         </p>
//                       </div>
//                     )}

//                     {/* Session Features */}
//                     <div className="mt-8 pt-8 border-t border-gray-200">
//                       <h4 className="font-medium text-gray-900 mb-3">Session Features</h4>
//                       <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
//                         <div className="flex items-center">
//                           <div className={`p-2 rounded-lg mr-3 ${
//                             selectedSession.chatEnabled ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-400'
//                           }`}>
//                             <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
//                               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
//                             </svg>
//                           </div>
//                           <div>
//                             <p className="font-medium">Chat</p>
//                             <p className="text-sm text-gray-500">
//                               {selectedSession.chatEnabled ? 'Enabled' : 'Disabled'}
//                             </p>
//                           </div>
//                         </div>
                        
//                         <div className="flex items-center">
//                           <div className={`p-2 rounded-lg mr-3 ${
//                             selectedSession.whiteboardEnabled ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-400'
//                           }`}>
//                             <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
//                               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
//                             </svg>
//                           </div>
//                           <div>
//                             <p className="font-medium">Whiteboard</p>
//                             <p className="text-sm text-gray-500">
//                               {selectedSession.whiteboardEnabled ? 'Enabled' : 'Disabled'}
//                             </p>
//                           </div>
//                         </div>
//                       </div>
//                     </div>
//                   </div>
//                 </>
//               ) : (
//                 <div className="p-12 text-center">
//                   <FileVideo className="h-16 w-16 text-gray-400 mx-auto mb-4" />
//                   <h3 className="text-lg font-semibold text-gray-900 mb-2">Select a Session</h3>
//                   <p className="text-gray-500">
//                     Choose a live session from the list to view its recordings
//                   </p>
//                 </div>
//               )}
//             </div>
//           </div>
//         </div>
//       </div>

//       {/* Footer Stats */}
//       <div className="mt-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
//         <div className="bg-white rounded-lg shadow p-6">
//           <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
//             <div className="text-center">
//               <div className="text-3xl font-bold text-blue-600">
//                 {course.liveClasses?.filter(s => s.status === 'COMPLETED').length || 0}
//               </div>
//               <div className="text-gray-600">Completed Sessions</div>
//             </div>
//             <div className="text-center">
//               <div className="text-3xl font-bold text-green-600">
//                 {sessionRecordings.length}
//               </div>
//               <div className="text-gray-600">Total Recordings</div>
//             </div>
//             <div className="text-center">
//               <div className="text-3xl font-bold text-purple-600">
//                 {course.enrolledCount || 0}
//               </div>
//               <div className="text-gray-600">Enrolled Students</div>
//             </div>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default CourseRecordingsPage;













import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import axios from 'axios';
import { useAuth } from '../../contexts/AuthContext';
import DashboardLayout from '../../utils/layout/DashboardLayout';
import {
  FaPlayCircle,
  FaCalendarAlt,
  FaClock,
  FaUser,
  FaVideo,
  FaArrowLeft,
  FaSpinner,
  FaExclamationCircle,
  FaExternalLinkAlt,
  FaFileVideo,
  FaUsers,
  FaHashtag,
  FaComment,
  FaChalkboard,
  FaCheckCircle,
  FaTimesCircle,
  FaRegCalendarCheck
} from 'react-icons/fa';

const CourseRecordingsPage = () => {
  const { courseId } = useParams();
  const navigate = useNavigate();
  const { token } = useAuth();
  
  const [course, setCourse] = useState(null);
  const [loading, setLoading] = useState(true);
  const [loadingRecordings, setLoadingRecordings] = useState(false);
  const [error, setError] = useState(null);
  const [selectedSession, setSelectedSession] = useState(null);
  const [sessionRecordings, setSessionRecordings] = useState([]);

  // Fetch course details
  useEffect(() => {
    const fetchCourseDetails = async () => {
      try {
        setLoading(true);
        setError(null);
        
        // Fetch course details from your API
        const response = await axios.get(
          `${import.meta.env.VITE_API_URL}/course/getAllCourses`,
          {
            headers: {
              'Authorization': `Bearer ${token}`,
              'Content-Type': 'application/json'
            },
          
          }
        );

        if (response.data.success) {
          // Find the specific course by ID
          const foundCourse = response.data.data.courses.find(
            course => course._id === courseId
          );
          
          if (foundCourse) {
            setCourse(foundCourse);
            // Set first session as selected by default if exists
            if (foundCourse.liveClasses && foundCourse.liveClasses.length > 0) {
              setSelectedSession(foundCourse.liveClasses[0]);
              // Fetch recordings for the first session
              fetchSessionRecordings(foundCourse.liveClasses[0].sessionId);
            }
          } else {
            setError('Course not found');
          }
        } else {
          setError('Failed to fetch course details');
        }
      } catch (err) {
        console.error('Error fetching course:', err);
        setError(err.response?.data?.message || 'Failed to load course details');
      } finally {
        setLoading(false);
      }
    };

    if (courseId && token) {
      fetchCourseDetails();
    }
  }, [courseId, token]);

  // Fetch recordings for a specific session
  const fetchSessionRecordings = async (sessionId) => {
    if (!sessionId) return;
    
    try {
      setLoadingRecordings(true);
      setSessionRecordings([]);
      
      const response = await axios.get(
        `${import.meta.env.VITE_API_URL}/liveSession/${sessionId}/recordings`,
        {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        }
      );

      if (response.data.success) {
        setSessionRecordings(response.data.data.recordings || []);
      } else {
        setSessionRecordings([]);
      }
    } catch (err) {
      console.error('Error fetching recordings:', err);
      setSessionRecordings([]);
    } finally {
      setLoadingRecordings(false);
    }
  };

  // Handle session selection
  const handleSessionSelect = (session) => {
    setSelectedSession(session);
    fetchSessionRecordings(session.sessionId);
  };

  // Format date
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  // Format time
  const formatTime = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Calculate session duration
  const getSessionDuration = (minutes) => {
    if (minutes < 60) {
      return `${minutes} min`;
    }
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return mins > 0 ? `${hours}h ${mins}m` : `${hours}h`;
  };

  // Get session status badge color
  const getStatusColor = (status) => {
    switch (status) {
      case 'SCHEDULED':
        return 'bg-blue-100 text-blue-800';
      case 'LIVE':
        return 'bg-green-100 text-green-800';
      case 'COMPLETED':
        return 'bg-purple-100 text-purple-800';
      case 'CANCELLED':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  // Get status icon
  const getStatusIcon = (status) => {
    switch (status) {
      case 'COMPLETED':
        return <FaCheckCircle className="inline mr-1" />;
      case 'SCHEDULED':
        return <FaRegCalendarCheck className="inline mr-1" />;
      case 'CANCELLED':
        return <FaTimesCircle className="inline mr-1" />;
      default:
        return null;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <FaSpinner className="h-12 w-12 animate-spin text-blue-600 mx-auto mb-4" />
          <p className="text-gray-600">Loading course details...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="max-w-md w-full bg-white rounded-lg shadow-lg p-8 text-center">
          <FaExclamationCircle className="h-16 w-16 text-red-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Error</h2>
          <p className="text-gray-600 mb-6">{error}</p>
          <button
            onClick={() => navigate('/courses')}
            className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
          >
            Back to Courses
          </button>
        </div>
      </div>
    );
  }

  if (!course) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="max-w-md w-full bg-white rounded-lg shadow-lg p-8 text-center">
          <FaExclamationCircle className="h-16 w-16 text-yellow-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Course Not Found</h2>
          <p className="text-gray-600 mb-6">The requested course could not be found.</p>
          <button
            onClick={() => navigate('/courses')}
            className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
          >
            Back to Courses
          </button>
        </div>
      </div>
    );
  }

  return (
    <DashboardLayout>
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between py-4">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => navigate(-1)}
                className="flex items-center text-gray-600 hover:text-gray-900 transition-colors"
              >
                <FaArrowLeft className="h-5 w-5 mr-2" />
                Back
              </button>
              <div className="h-8 w-px bg-gray-300" />
              <h1 className="text-2xl font-bold text-gray-900">Course Recordings</h1>
            </div>
            <Link
              to={`/courses/${courseId}`}
              className="flex items-center text-blue-600 hover:text-blue-800 transition-colors"
            >
              <FaExternalLinkAlt className="h-5 w-5 mr-2" />
              Go to Course
            </Link>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Course Info Card */}
        <div className="bg-white rounded-lg shadow-lg overflow-hidden mb-8 border border-gray-200">
          <div className="p-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
              <div className="flex-1">
                <h2 className="text-2xl font-bold text-gray-900 mb-2">{course.title}</h2>
                <p className="text-gray-600">{course.description}</p>
              </div>
              <div className="mt-4 md:mt-0 flex-shrink-0">
                <div className="flex items-center space-x-6">
                  <div className="flex items-center text-gray-600">
                    <FaUser className="h-5 w-5 mr-2 text-gray-400" />
                    <span className="font-medium">{course.instructor}</span>
                  </div>
                  <div className="flex items-center text-gray-600">
                    <FaVideo className="h-5 w-5 mr-2 text-gray-400" />
                    <span className="font-medium">{course.liveClasses?.length || 0} Sessions</span>
                  </div>
                </div>
              </div>
            </div>
            <div className="flex flex-wrap gap-4">
              <div className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
                {course.category}
              </div>
              <div className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-medium">
                {course.level}
              </div>
              <div className="px-3 py-1 bg-purple-100 text-purple-800 rounded-full text-sm font-medium">
                {course.duration} hours total
              </div>
              <div className="px-3 py-1 bg-yellow-100 text-yellow-800 rounded-full text-sm font-medium">
                {course.enrolledCount || 0} enrolled
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Sessions List */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-lg overflow-hidden border border-gray-200">
              <div className="px-6 py-4 border-b border-gray-200 bg-gray-50">
                <h3 className="text-lg font-semibold text-gray-900 flex items-center">
                  <FaCalendarAlt className="h-5 w-5 mr-2 text-blue-600" />
                  Live Sessions
                </h3>
                <p className="text-sm text-gray-500 mt-1">
                  Select a session to view recordings
                </p>
              </div>
              
              <div className="overflow-y-auto max-h-[600px]">
                {course.liveClasses && course.liveClasses.length > 0 ? (
                  <div className="divide-y divide-gray-200">
                    {course.liveClasses.map((session) => (
                      <button
                        key={session._id}
                        onClick={() => handleSessionSelect(session)}
                        className={`w-full text-left p-4 hover:bg-gray-50 transition-colors duration-200 ${
                          selectedSession?._id === session._id 
                            ? 'bg-blue-50 border-l-4 border-blue-600' 
                            : ''
                        }`}
                      >
                        <div className="flex justify-between items-start mb-2">
                          <h4 className="font-medium text-gray-900 text-sm">{session.sessionTitle}</h4>
                          <span className={`px-2 py-1 rounded-full text-xs font-medium flex items-center ${getStatusColor(session.status)}`}>
                            {getStatusIcon(session.status)}
                            {session.status}
                          </span>
                        </div>
                        
                        <div className="space-y-2 text-xs text-gray-600">
                          <div className="flex items-center">
                            <FaClock className="h-3 w-3 mr-2 flex-shrink-0" />
                            <span>
                              {formatDate(session.scheduleAt)} • {formatTime(session.scheduleAt)}
                            </span>
                          </div>
                          
                          <div className="flex items-center">
                            <FaHashtag className="h-3 w-3 mr-2 flex-shrink-0" />
                            <span className="font-mono">Room: {session.roomCode}</span>
                          </div>
                          
                          <div className="flex items-center">
                            <FaUsers className="h-3 w-3 mr-2 flex-shrink-0" />
                            <span>Duration: {getSessionDuration(session.duration)}</span>
                          </div>
                        </div>
                        
                        {session.description && (
                          <p className="mt-3 text-xs text-gray-500 line-clamp-2">
                            {session.description}
                          </p>
                        )}
                      </button>
                    ))}
                  </div>
                ) : (
                  <div className="p-8 text-center">
                    <FaCalendarAlt className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h4 className="font-medium text-gray-900 mb-2">No Live Sessions</h4>
                    <p className="text-gray-500 text-sm">This course doesn't have any live sessions yet.</p>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Right Column - Recordings */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-lg overflow-hidden border border-gray-200 h-full">
              {selectedSession ? (
                <>
                  <div className="px-6 py-4 border-b border-gray-200 bg-gray-50">
                    <div className="flex flex-col md:flex-row md:items-center justify-between">
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900 flex items-center">
                          <FaFileVideo className="h-5 w-5 mr-2 text-purple-600" />
                          Recordings for: {selectedSession.sessionTitle}
                        </h3>
                        <p className="text-sm text-gray-500 mt-1">
                          <FaCalendarAlt className="inline mr-1 h-3 w-3" />
                          Scheduled: {formatDate(selectedSession.scheduleAt)} at {formatTime(selectedSession.scheduleAt)}
                        </p>
                      </div>
                      <div className="mt-2 md:mt-0 flex items-center space-x-2">
                        <FaHashtag className="h-5 w-5 text-gray-400" />
                        <span className="font-mono bg-gray-100 px-3 py-1 rounded text-sm border border-gray-300">
                          {selectedSession.roomCode}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="p-6">
                    {loadingRecordings ? (
                      <div className="text-center py-12">
                        <FaSpinner className="h-12 w-12 animate-spin text-blue-600 mx-auto mb-4" />
                        <p className="text-gray-600">Loading recordings...</p>
                      </div>
                    ) : sessionRecordings.length > 0 ? (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {sessionRecordings.map((recording, index) => (
                          <div
                            key={index}
                            className="border border-gray-200 rounded-lg overflow-hidden hover:shadow-lg transition-shadow duration-300 bg-white"
                          >
                            <div className="aspect-video bg-gradient-to-br from-gray-900 to-gray-800 relative overflow-hidden">
                              {/* Video thumbnail preview */}
                              <div className="absolute inset-0 flex items-center justify-center">
                                <div className="relative">
                                  <FaPlayCircle className="h-16 w-16 text-white opacity-90" />
                                  <div className="absolute inset-0 animate-ping opacity-25">
                                    <FaPlayCircle className="h-16 w-16 text-white" />
                                  </div>
                                </div>
                              </div>
                              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 via-black/50 to-transparent p-4">
                                <div className="flex items-center justify-between">
                                  <p className="text-white font-medium text-sm">
                                    Recording {index + 1}
                                  </p>
                                  {recording.duration && (
                                    <span className="text-white text-xs bg-black/50 px-2 py-1 rounded">
                                      {getSessionDuration(recording.duration)}
                                    </span>
                                  )}
                                </div>
                              </div>
                            </div>
                            
                            <div className="p-4">
                              <h4 className="font-medium text-gray-900 mb-2 text-sm">
                                {recording.title || `Session Recording - Part ${index + 1}`}
                              </h4>
                              
                              {recording.createdAt && (
                                <p className="text-xs text-gray-500 mb-3 flex items-center">
                                  <FaClock className="h-3 w-3 mr-1" />
                                  Added: {new Date(recording.createdAt).toLocaleDateString()}
                                </p>
                              )}
                              
                              <a
                                href={recording.url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="inline-flex items-center justify-center w-full bg-gradient-to-r from-blue-600 to-blue-700 text-white px-4 py-2 rounded-lg hover:from-blue-700 hover:to-blue-800 transition-all duration-200 transform hover:-translate-y-0.5 shadow hover:shadow-md"
                              >
                                <FaPlayCircle className="h-4 w-4 mr-2" />
                                Watch Recording
                              </a>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-12">
                        <FaFileVideo className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                        <h4 className="font-medium text-gray-900 mb-2">No Recordings Available</h4>
                        <p className="text-gray-500 mb-6 max-w-md mx-auto">
                          {selectedSession.status === 'SCHEDULED'
                            ? 'Recordings will be available after the session is completed.'
                            : selectedSession.status === 'CANCELLED'
                            ? 'This session was cancelled and has no recordings.'
                            : 'No recordings were captured for this session.'}
                        </p>
                        <div className="flex flex-wrap items-center justify-center gap-4 text-sm text-gray-600">
                          <div className="flex items-center bg-gray-100 px-3 py-2 rounded-lg">
                            <FaUsers className="h-4 w-4 mr-2" />
                            <span>Status: {selectedSession.status}</span>
                          </div>
                          <div className="flex items-center bg-gray-100 px-3 py-2 rounded-lg">
                            <FaClock className="h-4 w-4 mr-2" />
                            <span>Duration: {getSessionDuration(selectedSession.duration)}</span>
                          </div>
                          <div className="flex items-center bg-gray-100 px-3 py-2 rounded-lg">
                            <FaHashtag className="h-4 w-4 mr-2" />
                            <span>Max Participants: {selectedSession.maxParticipants}</span>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Session Details */}
                    {selectedSession.description && (
                      <div className="mt-8 pt-8 border-t border-gray-200">
                        <h4 className="font-medium text-gray-900 mb-3 flex items-center">
                          <FaFileVideo className="h-4 w-4 mr-2 text-gray-500" />
                          Session Description
                        </h4>
                        <div className="bg-gray-50 rounded-lg p-4">
                          <p className="text-gray-600 whitespace-pre-line text-sm">
                            {selectedSession.description}
                          </p>
                        </div>
                      </div>
                    )}

                    {/* Session Features */}
                    <div className="mt-8 pt-8 border-t border-gray-200">
                      <h4 className="font-medium text-gray-900 mb-4 flex items-center">
                        <FaVideo className="h-4 w-4 mr-2 text-gray-500" />
                        Session Features
                      </h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className={`flex items-center p-3 rounded-lg border ${
                          selectedSession.chatEnabled 
                            ? 'border-green-200 bg-green-50' 
                            : 'border-gray-200 bg-gray-50'
                        }`}>
                          <div className={`p-2 rounded-lg mr-3 ${
                            selectedSession.chatEnabled 
                              ? 'bg-green-100 text-green-600' 
                              : 'bg-gray-100 text-gray-400'
                          }`}>
                            <FaComment className="h-5 w-5" />
                          </div>
                          <div>
                            <p className="font-medium text-sm">Live Chat</p>
                            <p className="text-xs text-gray-500">
                              {selectedSession.chatEnabled ? 'Enabled for interaction' : 'Disabled'}
                            </p>
                          </div>
                        </div>
                        
                        <div className={`flex items-center p-3 rounded-lg border ${
                          selectedSession.whiteboardEnabled 
                            ? 'border-blue-200 bg-blue-50' 
                            : 'border-gray-200 bg-gray-50'
                        }`}>
                          <div className={`p-2 rounded-lg mr-3 ${
                            selectedSession.whiteboardEnabled 
                              ? 'bg-blue-100 text-blue-600' 
                              : 'bg-gray-100 text-gray-400'
                          }`}>
                            <FaChalkboard className="h-5 w-5" />
                          </div>
                          <div>
                            <p className="font-medium text-sm">Interactive Whiteboard</p>
                            <p className="text-xs text-gray-500">
                              {selectedSession.whiteboardEnabled ? 'Enabled for collaboration' : 'Disabled'}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </>
              ) : (
                <div className="p-12 text-center">
                  <FaFileVideo className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">Select a Session</h3>
                  <p className="text-gray-500 max-w-md mx-auto">
                    Choose a live session from the list to view its recordings and details
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer Stats */}
        <div className="mt-8">
          <div className="bg-white rounded-lg shadow border border-gray-200 overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-200 bg-gray-50">
              <h3 className="font-semibold text-gray-900 flex items-center">
                <FaVideo className="h-5 w-5 mr-2 text-blue-600" />
                Course Statistics
              </h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 divide-y md:divide-y-0 md:divide-x divide-gray-200">
              <div className="text-center p-6">
                <div className="text-3xl font-bold text-blue-600 mb-2">
                  {course.liveClasses?.filter(s => s.status === 'COMPLETED').length || 0}
                </div>
                <div className="text-gray-600 flex items-center justify-center">
                  <FaCheckCircle className="h-4 w-4 mr-2 text-green-500" />
                  Completed Sessions
                </div>
              </div>
              <div className="text-center p-6">
                <div className="text-3xl font-bold text-purple-600 mb-2">
                  {sessionRecordings.length}
                </div>
                <div className="text-gray-600 flex items-center justify-center">
                  <FaFileVideo className="h-4 w-4 mr-2 text-purple-500" />
                  Total Recordings
                </div>
              </div>
              <div className="text-center p-6">
                <div className="text-3xl font-bold text-green-600 mb-2">
                  {course.enrolledCount || 0}
                </div>
                <div className="text-gray-600 flex items-center justify-center">
                  <FaUsers className="h-4 w-4 mr-2 text-green-500" />
                  Enrolled Students
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    </DashboardLayout>
  );
};

export default CourseRecordingsPage;